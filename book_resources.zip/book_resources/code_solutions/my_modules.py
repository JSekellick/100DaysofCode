class Wallet:
	def __init__(self):
		self.amount = 100
		self.currency = "Euro"

	def add_money(self, new_amount:int):
		self.amout += new_amount

	def display(self):
		print("Amount in Wallet: " 
			+ str (self.amount) 
			+ " " 
			+ str(self.currency))
