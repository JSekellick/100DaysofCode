import pygame
import time
pygame.mixer.init()
pygame.font.init()
screen_width, screen_height=900,600
main_window=pygame.display.set_mode((screen_width,screen_height))
pygame.display.set_caption("Coin Collector")


fps_rate = 60
player_velocity = 4
bg_img=pygame.image.load("assets/bg_image.jpg")
bg_img=pygame.transform.scale(bg_img,(screen_width,screen_height))
coin1 = pygame.Rect(200,200,20,20)
coin2 = pygame.Rect(200,250,20,20)
coin3 = pygame.Rect(250,200,20,20)
coin4 = pygame.Rect(250,250,20,20)

player_direction_x, player_direction_y = (0,0)


wall1 = pygame.Rect(100,100,100,100)
wall2 = pygame.Rect(300,100,100,100)
wall3 = pygame.Rect(500,100,100,100)
wall4 = pygame.Rect(700,100,100,100)

wall5 = pygame.Rect(100,300,100,100)
wall6 = pygame.Rect(300,300,100,100)
wall7 = pygame.Rect(500,300,100,100)
wall8 = pygame.Rect(700,300,100,100)


score = 0
coin_font = pygame.font.SysFont('arial',50)
level  = 1

level  = 1
timer = 0
timer_message = ""

menu_img = pygame.image.load("assets/menu.jpg")
menu_img = pygame.transform.scale(menu_img,(screen_width,screen_height))
info_font=pygame.font.SysFont('arial',30)

animation_frame = 0
player_angle = 0
p_1 = pygame.image.load("assets/p_1.png")
p_1 = pygame.transform.rotate(pygame.transform.scale(p_1,(25,25)),player_angle)
p_2 = pygame.image.load("assets/p_2.png")
p_2 = pygame.transform.rotate(pygame.transform.scale(p_2,(25,25)),player_angle)
p_3 = pygame.image.load("assets/p_3.png")
p_3 = pygame.transform.rotate(pygame.transform.scale(p_3,(25,25)),player_angle)
p_4 = pygame.image.load("assets/p_4.png")
p_4 = pygame.transform.rotate(pygame.transform.scale(p_4,(25,25)),player_angle)

p_5 = p_1
p_5_r = pygame.transform.rotate(pygame.transform.scale(p_5,(25,25)),player_angle)

coin_img=pygame.image.load("assets/coin.png")
coin_img=pygame.transform.scale(coin_img,(25,25))
beeping_snd = pygame.mixer.Sound('assets/beep.wav')


def animation():
    global p_1,p_2,p_3,p_4,p_5_r,p_5,animation_frame
    p_5_r = pygame.transform.rotate(p_5,player_angle)
    animation_frame += 1
    if animation_frame == 5:
        p_5 = p_1
    elif animation_frame == 10:
        p_5 = p_2
    elif animation_frame == 15:
        p_5 = p_3
    elif animation_frame == 20:
        p_5 = p_4
        animation_frame = 0


def victory():
    global score, level
    main_window.fill('White')
    info_text = info_font.render("YOU WON! ",1,"RED")
    main_window.blit(info_text,(340,270))
    pygame.display.update()
    time.sleep(2)
    while True:
        for event in pygame.event.get():
	     
            if event.type==pygame.QUIT:
	           
                pygame.quit()
        main_window.fill('White')
        info_text = info_font.render("PRESS R TO RESTART THE GAME ",1,"RED")
        main_window.blit(info_text,(100,270))
        pygame.display.update()
        key = pygame.key.get_pressed()
        if key[pygame.K_r]:
            level = 1
            score = 0
            change_level(1)
            menu()





def menu():
    while True:
        for event in pygame.event.get():
         
            if event.type==pygame.QUIT:
               
                pygame.quit()

            main_window.blit(menu_img,(0,0))
            key = pygame.key.get_pressed()
            instructions = info_font.render("Collect all coins in each level to access the next level",1,"RED")
            main_window.blit(instructions,(10,250))
            instructions_text = info_font.render("PRESS S TO START THE GAME",1,"Yellow")
            main_window.blit(instructions_text,(170,300))
            pygame.display.update()
            if key[pygame.K_s]:
                main()



def change_level(new_level):
	global coin1, coin2, coin3, coin4, wall1, wall2, wall3, wall4, wall5, wall6, wall7, wall8, level
	level = new_level
	if (level == 1):
		coin1=pygame.Rect(200,200,20,20)
		coin2=pygame.Rect(200,250,20,20)
		coin3=pygame.Rect(250,200,20,20)
		coin4=pygame.Rect(250,250,20,20)

		wall1=pygame.Rect(100,100,100,100)
		wall2=pygame.Rect(300,100,100,100)
		wall3=pygame.Rect(500,100,100,100)
		wall4=pygame.Rect(700,100,100,100)

		wall5=pygame.Rect(100,300,100,100)
		wall6=pygame.Rect(300,300,100,100)
		wall7=pygame.Rect(500,300,100,100)
		wall8=pygame.Rect(700,300,100,100)

	elif (level == 2):

		coin1.x, coin1.y = (20,90)
		coin2.x, coin2.y = (300,90)
		coin3.x, coin3.y = (10,500)
		coin4.x, coin4.y = (300,400)
		main()
	elif (level == 3):
	    victory()
	



def detect_collision(player_rect):
	global coin1,coin2,coin3,coin4, score, level, wall1, wall2, wall3, wall4, wall5, wall6, wall7, wall8
	if player_rect.colliderect(coin1):
		coin1.x=screen_width + 10
		score += 1
		pygame.mixer.Channel(1).play(beeping_snd)
	elif player_rect.colliderect(coin2):
		coin2.x=screen_width + 10
		score += 1
		pygame.mixer.Channel(1).play(beeping_snd)
	elif player_rect.colliderect(coin3):
		coin3.x=screen_width + 10
		score += 1
		pygame.mixer.Channel(1).play(beeping_snd)
	elif player_rect.colliderect(coin4):
		coin4.x=screen_width + 10
		score += 1
		pygame.mixer.Channel(1).play(beeping_snd)
	elif (
		player_rect.colliderect(wall1) or
		player_rect.colliderect(wall2) or
		player_rect.colliderect(wall3) or
		player_rect.colliderect(wall4) or
		player_rect.colliderect(wall5) or
		player_rect.colliderect(wall6) or
		player_rect.colliderect(wall7) or
		player_rect.colliderect(wall8)):
		print("COLLISION!")
		player_rect.y -= player_direction_y * player_velocity
		player_rect.x -= player_direction_x * player_velocity
	
	if (score == 4):
		score +=2
		change_level(level + 1)
	if (score == 10):
		change_level(level+1)





def display_main_window(player_rect):
	global p_5_r
	main_window.blit(bg_img,(0,0))

	#pygame.draw.rect(main_window,"Red",player_rect)
	if (player_angle == 180): p_5_r = pygame.transform.flip(p_5_r, 0,-1)
	main_window.blit(p_5_r,(player_rect.x,player_rect.y))


	#pygame.draw.rect(main_window,"Red",player_rect)
	#pygame.draw.rect(main_window,"Yellow",coin1)
	main_window.blit(coin_img,(coin1.x,coin1.y))    
	#pygame.draw.rect(main_window,"Yellow",coin2)
	main_window.blit(coin_img,(coin2.x,coin2.y))    
	#pygame.draw.rect(main_window,"Yellow",coin3)
	main_window.blit(coin_img,(coin3.x,coin3.y))    
	#pygame.draw.rect(main_window,"Yellow",coin4) 
	main_window.blit(coin_img,(coin4.x,coin4.y))


	pygame.draw.rect(main_window,"Black",wall1)
	pygame.draw.rect(main_window,"Black",wall2)
	pygame.draw.rect(main_window,"Black",wall3)
	pygame.draw.rect(main_window,"Black",wall4) 


	pygame.draw.rect(main_window,"Black",wall5)
	pygame.draw.rect(main_window,"Black",wall6)
	pygame.draw.rect(main_window,"Black",wall7)
	pygame.draw.rect(main_window,"Black",wall8)
	
	
	score_text = coin_font.render("Score = "+str(score),1,"Yellow")
	main_window.blit(score_text,(10,10))



	level_text = coin_font.render("Level = " + str(level),1,"Red")
	main_window.blit(level_text,(screen_width/2 ,10)) 


	time_text = coin_font.render("Time = "+timer_message,1,"Green")
	main_window.blit(time_text,(screen_width/2 ,screen_height - 50)) 


	pygame.display.update()


def controls(keys_pressed,player_rect):
	global player_direction_x
	global player_direction_y
	global player_angle

	if keys_pressed[pygame.K_LEFT] and player_rect.x>10 :
		player_rect.x -=player_velocity        
		player_direction_x, player_direction_y = (-1,0)
		player_angle = 0
	if keys_pressed[pygame.K_RIGHT] and player_rect.x<screen_width-10 :
		player_rect.x +=player_velocity
		player_direction_x, player_direction_y = (1,0)
		player_angle = 180
	if keys_pressed[pygame.K_UP] and player_rect.y>10 :
		player_rect.y -=player_velocity
		player_direction_x, player_direction_y = (0,-1)
		player_angle = -90        
	if keys_pressed[pygame.K_DOWN] and player_rect.y<(screen_height -10 - 25) :
		player_rect.y +=player_velocity
		player_direction_x, player_direction_y = (0,1)
		player_angle = +90        


def main():
	global timer, timer_message
	player_rect=pygame.Rect(50,300,25,25)
	clock= pygame.time.Clock()
	

	Time=120
	while True:
		clock.tick(fps_rate)
		timer += clock.tick(fps_rate)/1000 
		minutes = int (timer/60)
		seconds = int (timer%60)
		timer_message = str(minutes) + ":" + str(seconds)
		if (timer >= 120): 
			change_level(level)
			timer = 0
		for event in pygame.event.get():
		 
			if event.type==pygame.QUIT:
				pygame.quit()

		key = pygame.key.get_pressed()	   
		display_main_window(player_rect)
		controls(key,player_rect)
		detect_collision(player_rect)
		animation()



menu()