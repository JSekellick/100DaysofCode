import numpy as np 
import random

word_to_guess = "";
string_to_display=""
length_of_word_to_guess = 0;
letters_to_guess = ""
letters_guessed=""
new_letter = ''
stay_in_loop = 1
nb_attempts = 1
max_nb_attemps = 5


def init_game():

	global word_to_guess
	global string_to_display
	global length_of_word_to_guess
	global letters_to_guess
	global letters_guessed
	global new_letter

	'''words_to_guess = ["car","elephant","autocar"]
	random_number = random.randint(0,len(words_to_guess)-1)
	word_to_guess = words_to_guess[random_number]'''
	set_word_from_file()

	length_of_word_to_guess = len(word_to_guess)
	word_to_guess = word_to_guess.upper ()
	letters_to_guess = np.array(length_of_word_to_guess)
	letters_guessed = np.array(length_of_word_to_guess)
	letters_guessed = np.zeros(length_of_word_to_guess)
	letters_to_guess = [char for char in word_to_guess]
	string_to_display = ""
	for i in range (length_of_word_to_guess):
		string_to_display+="?"

def display_letters():
	print(string_to_display)


def check_keyboard():
	global word_to_guess
	global string_to_display
	global length_of_word_to_guess
	global letters_to_guess
	global letters_guessed
	global new_letter
	global nb_attempts
	global max_nb_attemps

	new_letter = str(raw_input("Attempt " + str(nb_attempts) + ">"))
	new_letter = new_letter.upper()
	nb_attempts += 1

	for i in range (length_of_word_to_guess):
		if (ord(new_letter) >=65 and ord(new_letter) <= 90):
			if (not letters_guessed [i]):
				if (letters_to_guess [i] == new_letter):
						letters_guessed [i] = 1
						string_to_display = replace_char_at_index(string_to_display,new_letter,i)
				else:
					if (nb_attempts >= max_nb_attemps):
							print("Sorry Max Nb Attempts Reached")
							nb_attempts = 0
							init_game()
							game_loop()



def game_loop():
	while (stay_in_loop):
		display_letters()
		check_keyboard()

def replace_char_at_index(string_to_work_with, new_character, index):
	string_to_be_returned = ""
	string_to_be_returned = string_to_work_with[:index]+new_character+string_to_work_with[index+1:]
	return (string_to_be_returned)


def set_word_from_file():
	global word_to_guess
	global string_to_display
	global length_of_word_to_guess
	global letters_to_guess
	global letters_guessed
	global new_letter

	with open('words.txt') as f:
		lines = f.readlines()
		random_number = random.randint(0,len(lines)-1)
		word_to_guess = lines[random_number]
		word_to_guess = word_to_guess.replace("\n","")
		word_to_guess = word_to_guess.replace("\r","")


def set_word_from_array():
	global word_to_guess
	global string_to_display
	global length_of_word_to_guess
	global letters_to_guess
	global letters_guessed
	global new_letter
	words_to_guess = ["car","elephant","autocar"]
	#print(words_to_guess[1])
	random_number = random.randint(0,len(words_to_guess)-1)
	word_to_guess = words_to_guess[random_number]



init_game()
game_loop()