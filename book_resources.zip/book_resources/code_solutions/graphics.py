import pygame
pygame.display.init()
scr = pygame.display.set_mode((600,500))  
pygame.display.set_caption('Pygame Window')


color = (0,0,255) 
start_x = 10
start_y = 10
rect_width = 100
rect_height = 100


pygame.draw.rect(scr, color, pygame.Rect(start_x,start_y, rect_width, rect_height))

color = (255,0,0) 
circle_center = (200, 60)
circle_radius = 50
pygame.draw.circle(scr, color, circle_center, circle_radius, 3)


cross_start_x = 300
cross_start_y = 10
pygame.draw.line(scr, color,(cross_start_x, cross_start_y), (cross_start_x + 100, cross_start_y + 100),3)
pygame.draw.line(scr, color,(cross_start_x, cross_start_y+100), (cross_start_x + 100, cross_start_y ),3)


pygame.display.flip()

done = False
while not done:
	for event in pygame.event.get():  
		if event.type == pygame.QUIT:
			done = True  
	pass

