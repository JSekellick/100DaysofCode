import random

number_to_guess = 0;
nb_attempts = 1
min_value = 0
max_value = 100


def game_loop():
	
	while (True):
		ask_for_new_number()


def init_game():

	global number_to_guess
	global min_value
	global max_value
	global nb_attempts
	min_value = input("Please enter the minimum value: ")
	max_value = input("Please enter the maximum value: ")
	min_value = int(min_value)
	max_value = int(max_value)

	number_to_guess = random.randint(min_value,max_value)
	nb_attemps = 0


def ask_for_new_number():
	global number_to_guess
	global nb_attempts
	global min_value
	global max_value
	new_number = input("Please enter your number ["
	+str(min_value)
	+"-"
	+str(max_value)
	+"]: ")
	new_number = int(new_number)
	nb_attempts +=1
	if (number_to_guess > new_number):
		print("> My Number is greater than " + str(new_number))
	elif (number_to_guess < new_number):
		print("> My Number is lesser than " + str(new_number))
	else: 
		print ("\n *** Well done; you have guessed my number; it took " 
			+ str(nb_attempts) 
			+ " attempts")
		print ("\n\n *** New Game***")
		
init_game()
game_loop()



