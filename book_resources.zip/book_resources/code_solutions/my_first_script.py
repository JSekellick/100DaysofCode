import my_modules
number = 12
my_name = "Patrick"
#print ("Hello " + my_name + " , your number is "+ str(number))
def my_first_function():
	print("Hello World")

def my_second_function(name):
	print("Hello, your name is " + name)

my_first_function()
my_second_function("Patrick")

def calculate_age(YOB):
	age = 2021-YOB
	return (age)
my_age = calculate_age(1998)
print ("Your age is " + str(my_age))


class Bike:

	def __init__(self, new_name:str = "A New Bike", new_color:str = "Blue",new_speed:int = 0):
		self.name = new_name
		self.color = new_color
		self.speed = new_speed

	def display_name(self):
		print("Name: "+self.name)

	def display_color(self):
		print("Color is: " + self.color)

	def accelerate(self):
		self.speed += 1
		print("New speed: "+str(self.speed))

my_bike = Bike();
my_bike.display_color()
my_bike.display_name()
my_bike.accelerate()

my_bike2:Bike = Bike("My Bike","Red",10)
my_bike2.display_color()
my_bike2.display_name()
my_bike2.accelerate()



wallet = my_modules.Wallet()
wallet.display()
