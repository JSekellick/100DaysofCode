import pygame
import pygame.mouse
from pygame.locals import *
pygame.init()

scr = pygame.display.set_mode((600,500))  
pygame.display.set_caption('Pygame Window')
color = (0,0,255) 
start_x = 10
start_y = 10
rect_width = 100
rect_height = 100
margin_x = 5
margin_y = 5

cell_used = [[0,0,0],[0,0,0],[0,0,0]]

def check_if_a_player_won():
	global cell_used	
	found_a_line = False
	line1_sum = cell_used[0][0] + cell_used[0][1] + cell_used[0][2]
	line2_sum = cell_used[1][0] + cell_used[1][1] + cell_used[1][2]
	line3_sum = cell_used[2][0] + cell_used[2][1] + cell_used[2][2]

	col1_sum = cell_used[0][0] + cell_used[1][0] + cell_used[2][0]
	col2_sum = cell_used[0][0] + cell_used[1][0] + cell_used[2][0]
	col3_sum = cell_used[0][2] + cell_used[1][2] + cell_used[2][2]

	diagno1_sum = cell_used[0][0] + cell_used[1][1] + cell_used[2][2]
	diagno2_sum = cell_used[2][0] + cell_used[1][1] + cell_used[0][2]

	line1_prod = cell_used[0][0] * cell_used[0][1] * cell_used[0][2]
	line2_prod = cell_used[1][0] * cell_used[1][1] * cell_used[1][2]
	line3_prod = cell_used[2][0] * cell_used[2][1] * cell_used[2][2]

	col1_prod = cell_used[0][0] * cell_used[1][0] * cell_used[2][0]
	col2_prod = cell_used[0][0] * cell_used[1][0] * cell_used[2][0]
	col3_prod = cell_used[0][2] * cell_used[1][2] * cell_used[2][2]

	diagno1_prod = cell_used[0][0] * cell_used[1][1] * cell_used[2][2]
	diagno2_prod = cell_used[2][0] * cell_used[1][1] * cell_used[0][2]
	if (abs(line1_sum) == 3 
		or abs(line2_sum) == 3 
		or abs(line3_sum) == 3 
		or abs(col1_sum) == 3 
		or abs(col2_sum) == 3 
		or abs(col3_sum) == 3 
		or abs(diagno1_sum) == 3 
		or abs(diagno2_sum) == 3):
			if (line1_prod > 0 
			or line2_prod > 0 
			or line3_prod > 0 
			or col1_prod > 0 
			or col2_prod > 0 
			or col3_prod > 0 
			or diagno1_prod > 0 
			or diagno2_prod > 0):
				print ("GAME OVER >> PLAYER WINS")
			else:
				print ("GAME OVER >> COMPUTER WINS")







def computer_plays_simple():
	global start_x
	global start_y
	global rect_width
	global rect_height
	global margin_x
	global margin_y

	global cell_used
	is_looping = True
	for j in range (3):
		for i in range (3):
			if (cell_used[j][i] == 0):
				cell_used[j][i] = -1
				cell_top_left_x = start_x+(rect_width+margin_x)*i
				cell_top_left_y = start_y+(rect_height+margin_y)*j
				color = (0,255,0)
				circle_center = (cell_top_left_x + rect_width/2,cell_top_left_y + rect_height/2)
				circle_radius = (rect_width)*.8/2
				pygame.draw.circle(scr, color, circle_center, circle_radius, 7)	
				pygame.display.flip()
				is_looping = False
				break
		if (is_looping == False):
				break	





def detect_square_clicked(x,y):
	global start_x
	global start_y
	global rect_width
	global rect_height
	global margin_x
	global margin_y
	global cell_used
	print("Clicked at x="+str(x)+"__y="+str(y))
	new_x_pos = ((x - start_x)/(rect_width + margin_x))
	new_y_pos = ((y - start_y)/(rect_height + margin_y))

	new_x_pos = int(new_x_pos)
	new_y_pos = int(new_y_pos)
	if (cell_used [new_y_pos][new_x_pos] == 0):
		cell_used [new_y_pos][new_x_pos] = 1
		color = (255,0,0)
		cross_top_left_x = start_x+(rect_width+margin_x)*new_x_pos;
		cross_top_left_y = start_y+(rect_height+margin_y)*new_y_pos
		pygame.draw.line(
		scr,
		color,
		(cross_top_left_x ,cross_top_left_y),
		(cross_top_left_x + rect_width, cross_top_left_y +rect_height),
		7)
		pygame.draw.line(
			scr,
			color,
			(cross_top_left_x ,cross_top_left_y + rect_height),
			(cross_top_left_x + rect_width, cross_top_left_y),
			7)
		pygame.display.flip()





for i in range (3):
	for j in range (3):
		pygame.draw.rect(
			scr, 
			color, 
			pygame.Rect(start_x+(rect_width+margin_x)*i,
				start_y+(rect_height+margin_y)*j,
				rect_width, rect_height))
pygame.display.flip()

done = False
while not done:
	for event in pygame.event.get():  
		if event.type == pygame.QUIT:
			done = True  
		if event.type == MOUSEBUTTONDOWN:
			if event.button == 1:
				position  = pygame.mouse.get_pos()
				detect_square_clicked(position[0],position[1])
				check_if_a_player_won()
				computer_plays_simple()
				check_if_a_player_won()
	pass
