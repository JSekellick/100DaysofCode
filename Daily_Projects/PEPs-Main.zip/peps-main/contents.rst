.. This file is placed in the public domain or under the
   CC0-1.0-Universal license, whichever is more permissive.

Python Enhancement Proposals (PEPs)
***********************************

This is an internal Sphinx page; please go to the :doc:`PEP Index <pep-0000>`.


.. toctree::
   :maxdepth: 3
   :titlesonly:
   :hidden:
   :glob:
   :caption: PEP Table of Contents (needed for Sphinx):

   docs/*
   pep-*
   topic/*
